package com.example.citas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun Menu(
    rol: String,
    nombreUsuario: String,
    viewModel: CitasViewModel,
    onAgendarCitaClick: () -> Unit,
    onHistorialClick: () -> Unit,
    onProfileClick: () -> Unit,
    onGestionSucursalesClick: () -> Unit,
    onGestionServiciosClick: () -> Unit,
    onGestionEmpleadosClick: () -> Unit
) {
    val primaryPink = Color(0xFFE91E63)
    val lightPink = Color(0xFFFDE4E9)
    val citasVisibles = viewModel.obtenerCitasFiltradas(rol, nombreUsuario)

    Column(
        modifier = Modifier.fillMaxSize().background(Color.White)
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = lightPink)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ESTÉTICA ESTELLA", color = primaryPink, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onProfileClick) {
                        Icon(Icons.Default.Person, null, tint = primaryPink, modifier = Modifier.background(Color.White, CircleShape).padding(4.dp))
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text("Hola, $nombreUsuario", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(24.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onAgendarCitaClick, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color.Black)) {
                        Text("Nueva cita")
                    }
                    OutlinedButton(onClick = onHistorialClick, modifier = Modifier.weight(1f)) {
                        Text("Historial", color = Color.Black)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text("Próximas Citas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        if (citasVisibles.isEmpty()) {
            Text("No tienes citas agendadas.", modifier = Modifier.padding(top = 16.dp), color = Color.Gray)
        } else {
            citasVisibles.forEach { cita ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    ListItem(
                        headlineContent = { Text(cita.servicio, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text("${cita.fecha} | ${cita.hora}") },
                        trailingContent = { Text(cita.estado, color = primaryPink) }
                    )
                }
            }
        }

        if (rol.trim().lowercase() == "admin") {
            Spacer(modifier = Modifier.height(32.dp))
            Text("Panel de Administración", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            AdminActionCard("Sucursales", Icons.Default.LocationOn, onGestionSucursalesClick)
            AdminActionCard("Servicios", Icons.Default.List, onGestionServiciosClick)
            AdminActionCard("Empleados", Icons.Default.Face, onGestionEmpleadosClick)
        }
    }
}

@Composable
fun AdminActionCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8F8F8)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Color.DarkGray)
            Spacer(Modifier.width(16.dp))
            Text(title, modifier = Modifier.weight(1f))
            Icon(Icons.Default.KeyboardArrowRight, null, tint = Color.LightGray)
        }
    }
}