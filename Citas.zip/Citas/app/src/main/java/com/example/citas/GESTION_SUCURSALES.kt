package com.example.citas

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionSucursales(viewModel: CitasViewModel, onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Información de Sucursal") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(80.dp), tint = Color(0xFFE91E63))
            Text(viewModel.SUCURSAL_UNICA, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(16.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("📍 Dirección: Av. Principal #456, Col. Centro", style = MaterialTheme.typography.bodyLarge)
                    Text("📞 Teléfono: 555-0192", style = MaterialTheme.typography.bodyLarge)
                    Text("⏰ Horario: Lunes a Sábado de 9:00 a 20:00", style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}