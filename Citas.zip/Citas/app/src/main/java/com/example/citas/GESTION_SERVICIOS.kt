package com.example.citas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionServicios(viewModel: CitasViewModel, onBack: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Servicios") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Servicio") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = precio, onValueChange = { precio = it }, label = { Text("Precio") }, modifier = Modifier.fillMaxWidth())

            Button(
                onClick = {
                    if (nombre.isNotEmpty() && precio.isNotEmpty()) {
                        viewModel.listaServicios.add(Servicio(viewModel.listaServicios.size + 1, nombre, precio.toDoubleOrNull() ?: 0.0, "60 min"))
                        nombre = ""; precio = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) { Text("GUARDAR") }

            LazyColumn {
                items(viewModel.listaServicios) { servicio ->
                    ListItem(
                        headlineContent = { Text(servicio.nombre) },
                        supportingContent = { Text("$${servicio.precio}") },
                        trailingContent = {
                            IconButton(onClick = { viewModel.listaServicios.remove(servicio) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Borrar")
                            }
                        }
                    )
                }
            }
        }
    }
}