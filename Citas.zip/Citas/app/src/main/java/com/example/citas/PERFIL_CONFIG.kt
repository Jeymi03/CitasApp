package com.example.citas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Perfil(
    userDAO: UserDAO,
    currentEmail: String,
    userRole: String,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val datosUsuario = remember { userDAO.getUserData(currentEmail) }
    var name by remember { mutableStateOf(datosUsuario?.third ?: "") }
    var password by remember { mutableStateOf("") }

    val primaryPink = Color(0xFFE91E63)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mi Perfil", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Atrás") } },
                actions = { IconButton(onClick = onLogout) { Icon(Icons.Default.ExitToApp, "Salir", tint = primaryPink) } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(24.dp)) {
            Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFFFDE4E9)).padding(24.dp)) {
                Text("INFORMACIÓN PERSONAL", fontWeight = FontWeight.Bold, color = primaryPink)

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = currentEmail, onValueChange = {}, label = { Text("Correo") }, enabled = false, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Nueva Contraseña") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        val finalHash = if (password.isNotEmpty()) hashSHA512(password) else datosUsuario?.first ?: ""
                        userDAO.addUser(name, currentEmail, finalHash, userRole)
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                ) {
                    Text("ACTUALIZAR DATOS", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}