package com.example.citas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Inicio_sesion(
    userDAO: UserDAO,
    onSuccess: (String, String, String) -> Unit,
    onRegister: () -> Unit
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var emailText by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val roles = listOf("CLIENTE", "ADMIN", "EMPLEADO")
    val primaryPink = Color(0xFFE91E63)

    Box(modifier = Modifier.fillMaxSize().background(Color.White).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xFFFDE4E9))
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("ESTÉTICA ESTELLA", fontWeight = FontWeight.Bold, color = primaryPink, fontSize = 24.sp)

            Spacer(modifier = Modifier.height(24.dp))

            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.White.copy(alpha = 0.5f),
                contentColor = primaryPink,
                divider = {}
            ) {
                roles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index; errorMessage = "" },
                        text = { Text(title, fontSize = 10.sp, fontWeight = if(selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = emailText,
                onValueChange = { emailText = it },
                label = { Text("Correo Electrónico") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (errorMessage.isNotEmpty()) {
                Text(errorMessage, color = Color.Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    val cleanEmail = emailText.trim().lowercase()
                    val cleanPass = password.trim()
                    val userData = userDAO.getUserData(cleanEmail)
                    val selectedRolStr = roles[selectedTabIndex].uppercase()

                    if (userData != null) {

                        val inputHash = hashSHA512(cleanPass)
                        if (inputHash == userData.first) {
                            if (userData.second.uppercase() == selectedRolStr) {
                                onSuccess(cleanEmail, userData.second.lowercase(), userData.third)
                            } else {
                                errorMessage = "El usuario es ${userData.second}, no $selectedRolStr"
                            }
                        } else {
                            errorMessage = "Contraseña incorrecta para $cleanEmail"
                        }
                    } else {
                        errorMessage = "El correo no está registrado"
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("INICIAR SESIÓN", color = Color.White, fontWeight = FontWeight.Bold)
            }

            TextButton(onClick = onRegister) {
                Text("¿No tienes cuenta? Regístrate aquí", color = primaryPink)
            }
        }
    }
}