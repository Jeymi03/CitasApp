package com.example.citas

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionEmpleados(viewModel: CitasViewModel, onBack: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var especialidad by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gestionar Personal", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text("Registrar Nuevo Empleado", color = Color(0xFFE91E63), fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre Completo") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = especialidad,
                onValueChange = { especialidad = it },
                label = { Text("Especialidad (ej. Manicurista, Barbero)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (nombre.isNotEmpty() && especialidad.isNotEmpty()) {
                        viewModel.listaEmpleados.add(
                            Empleado(
                                id = viewModel.listaEmpleados.size + 1,
                                nombre = nombre,
                                especialidad = especialidad,
                                sucursal = viewModel.SUCURSAL_UNICA // Solo una sucursal
                            )
                        )
                        nombre = ""; especialidad = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Text("REGISTRAR EN SUCURSAL ÚNICA")
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Personal Actual", fontWeight = FontWeight.Bold, fontSize = 18.sp)

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(viewModel.listaEmpleados) { empleado ->
                    EmpleadoItem(
                        empleado = empleado,
                        onDelete = { viewModel.listaEmpleados.remove(empleado) }
                    )
                }
            }
        }
    }
}

@Composable
fun EmpleadoItem(empleado: Empleado, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        border = BorderStroke(1.dp, Color.LightGray),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF4F5))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.AccountBox, contentDescription = null, tint = Color(0xFFE91E63))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(empleado.nombre, fontWeight = FontWeight.Bold)
                Text("${empleado.especialidad} | ${empleado.sucursal}", fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color.Gray)
            }
        }
    }
}