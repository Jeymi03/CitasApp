package com.example.citas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val citasViewModel = ViewModelProvider(this)[CitasViewModel::class.java]
        setContent { AppScreens(citasViewModel) }
    }
}

@Composable
fun AppScreens(viewModel: CitasViewModel) {
    val userDAO = remember { UserDAO() }
    var currentScreen by remember { mutableStateOf(Pantalla.BIENVENIDA) }
    var userName by remember { mutableStateOf("Usuario") }
    var userRole by remember { mutableStateOf("cliente") }
    var userEmail by remember { mutableStateOf("") }

    when (currentScreen) {
        Pantalla.BIENVENIDA -> Bienvenida(
            onLoginClick = { currentScreen = Pantalla.INICIO_SESION },
            onRegisterClick = { currentScreen = Pantalla.REGISTRO }
        )
        Pantalla.INICIO_SESION -> Inicio_sesion(
            userDAO = userDAO,
            onSuccess = { email, rol, nombre ->
                userEmail = email; userName = nombre; userRole = rol
                currentScreen = Pantalla.INICIO
            },
            onRegister = { currentScreen = Pantalla.REGISTRO }
        )
        Pantalla.REGISTRO -> Registro(
            onRegisterSuccess = { currentScreen = Pantalla.INICIO_SESION },
            onBack = { currentScreen = Pantalla.BIENVENIDA }
        )
        Pantalla.INICIO -> Menu(
            rol = userRole,
            nombreUsuario = userName,
            viewModel = viewModel,
            onAgendarCitaClick = { currentScreen = Pantalla.AGENDAR_CITA },
            onHistorialClick = { currentScreen = Pantalla.HISTORIAL },
            onProfileClick = { currentScreen = Pantalla.PERFIL_CONFIG },
            onGestionSucursalesClick = { currentScreen = Pantalla.GESTION_SUCURSALES },
            onGestionServiciosClick = { currentScreen = Pantalla.GESTION_SERVICIOS },
            onGestionEmpleadosClick = { currentScreen = Pantalla.GESTION_EMPLEADOS }
        )
        Pantalla.GESTION_EMPLEADOS -> GestionEmpleados(viewModel, onBack = { currentScreen = Pantalla.INICIO })
        Pantalla.GESTION_SERVICIOS -> GestionServicios(viewModel, onBack = { currentScreen = Pantalla.INICIO })
        Pantalla.GESTION_SUCURSALES -> GestionSucursales(viewModel, onBack = { currentScreen = Pantalla.INICIO })
        Pantalla.AGENDAR_CITA -> Agendar_cita(viewModel, userName, onBack = { currentScreen = Pantalla.INICIO })
        Pantalla.HISTORIAL -> HistorialCitas(userRole, userName, viewModel, onBack = { currentScreen = Pantalla.INICIO })
        Pantalla.PERFIL_CONFIG -> Perfil(userDAO, userEmail, userRole, onBack = { currentScreen = Pantalla.INICIO }, onLogout = { currentScreen = Pantalla.BIENVENIDA })
    }
}