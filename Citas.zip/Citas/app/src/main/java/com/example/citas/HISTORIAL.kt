package com.example.citas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HistorialCitas(
    rol: String,
    nombreUsuario: String,
    viewModel: CitasViewModel,
    onBack: () -> Unit
) {
    val accentPink = Color(0xFFFDE4E9)
    val primaryPink = Color(0xFFE91E63)
    val listaCitas = viewModel.obtenerCitasFiltradas(rol, nombreUsuario)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(accentPink)
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.Default.ArrowBack,
                    contentDescription = "Atrás",
                    tint = primaryPink
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Historial de Citas",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }

        Spacer(Modifier.height(24.dp))

        if (listaCitas.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No hay registros en el historial.", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(listaCitas) { cita ->
                    HistorialCitaCard(cita = cita, esAdmin = (rol == "admin" || rol == "empleado"))
                }
            }
        }
    }
}

@Composable
fun HistorialCitaCard(cita: Cita, esAdmin: Boolean) {
    val primaryPink = Color(0xFFE91E63)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (esAdmin) {
                        Text(
                            text = "CLIENTE: ${cita.clienteNombre.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = primaryPink
                        )
                    }
                    Text(
                        text = cita.servicio,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
                ChipEstado(estado = cita.estado)
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                thickness = 0.5.dp,
                color = Color.LightGray
            )

            Text(text = "Estilista: ${cita.estilista}", color = Color.Gray, fontSize = 14.sp)
            Text(text = "${cita.fecha} | ${cita.hora}", color = Color.Gray, fontSize = 14.sp)

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Total", color = Color.DarkGray, fontSize = 14.sp)
                Text(
                    text = cita.precio,
                    fontWeight = FontWeight.ExtraBold,
                    color = primaryPink,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun ChipEstado(estado: String) {
    val color = when (estado) {
        "Próxima" -> Color(0xFF2196F3)
        "Completada" -> Color(0xFF4CAF50)
        "Cancelada" -> Color(0xFFF44336)
        else -> Color.Gray
    }
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.12f),
        modifier = Modifier.wrapContentSize()
    ) {
        Text(
            text = estado,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}