package com.example.citas

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*
import androidx.compose.foundation.shape.RoundedCornerShape

@Composable
fun Agendar_cita(
    viewModel: CitasViewModel,
    nombreCliente: String,
    onBack: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }
    var selectedService by remember { mutableStateOf<Servicio?>(null) }
    var selectedEmpleado by remember { mutableStateOf<Empleado?>(null) }
    var selectedDate by remember { mutableStateOf("Seleccionar Fecha") }
    var selectedTime by remember { mutableStateOf("Seleccionar Hora") }
    val context = LocalContext.current
    val primaryPink = Color(0xFFE91E63)

    Column(modifier = Modifier.fillMaxSize().background(Color.White).padding(16.dp)) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Volver", tint = primaryPink)
        }

        Text(
            text = "Paso $step de 3",
            color = primaryPink,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(modifier = Modifier.weight(1f)) {
            when (step) {
                1 -> Column {
                    Text("¿Qué servicio deseas?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    LazyColumn {
                        items(viewModel.listaServicios) { svc ->
                            ServiceSelectCard(svc, svc == selectedService) { selectedService = svc }
                        }
                    }
                }
                2 -> Column {
                    Text("Elige a tu estilista", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    LazyColumn {
                        items(viewModel.listaEmpleados) { emp ->
                            EmpleadoSelectCard(emp, emp == selectedEmpleado) { selectedEmpleado = emp }
                        }
                    }
                }
                3 -> Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("Fecha y Hora", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Text("Servicio: ${selectedService?.nombre}", color = Color.Gray)
                    Text("Atendido por: ${selectedEmpleado?.nombre}", color = Color.Gray)

                    Spacer(Modifier.height(32.dp))

                    Button(
                        onClick = {
                            val calendar = Calendar.getInstance()
                            DatePickerDialog(context, { _, y, m, d -> selectedDate = "$d/${m + 1}/$y" },
                                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
                        },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF5F5F5), contentColor = Color.Black)
                    ) { Text(selectedDate) }

                    Button(
                        onClick = {
                            TimePickerDialog(context, { _, h, min -> selectedTime = String.format("%02d:%02d", h, min) }, 12, 0, true).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF5F5F5), contentColor = Color.Black)
                    ) { Text(selectedTime) }
                }
            }
        }

        Button(
            onClick = {
                if (step < 3) step++
                else {
                    viewModel.agregarCita(Cita(
                        id = (1..1000).random(),
                        clienteNombre = nombreCliente,
                        servicio = selectedService?.nombre ?: "",
                        estilista = selectedEmpleado?.nombre ?: "",
                        fecha = selectedDate,
                        hora = selectedTime,
                        precio = "${selectedService?.precio ?: 0.0}",
                        estado = "Próxima"
                    ))
                    onBack()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            enabled = (step == 1 && selectedService != null) ||
                    (step == 2 && selectedEmpleado != null) ||
                    (step == 3 && selectedDate != "Seleccionar Fecha" && selectedTime != "Seleccionar Hora"),
            colors = ButtonDefaults.buttonColors(containerColor = primaryPink),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(if (step == 3) "CONFIRMAR CITA" else "SIGUIENTE", fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceSelectCard(servicio: Servicio, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color.Black else Color(0xFFF5F5F5),
            contentColor = if (isSelected) Color.White else Color.Black
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(servicio.nombre, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("$${servicio.precio}", fontWeight = FontWeight.Bold, color = if (isSelected) Color.White else Color(0xFFE91E63))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmpleadoSelectCard(empleado: Empleado, isSelected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color.Black else Color(0xFFF5F5F5),
            contentColor = if (isSelected) Color.White else Color.Black
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.padding(end = 12.dp))
            Column {
                Text(empleado.nombre, fontWeight = FontWeight.Bold)
                Text(empleado.especialidad, fontSize = 12.sp, color = if (isSelected) Color.LightGray else Color.Gray)
            }
        }
    }
}