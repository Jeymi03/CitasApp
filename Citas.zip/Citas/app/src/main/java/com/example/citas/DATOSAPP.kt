package com.example.citas

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import java.security.MessageDigest
import android.util.Base64

enum class Pantalla {
    BIENVENIDA, INICIO_SESION, REGISTRO, INICIO,
    AGENDAR_CITA, HISTORIAL, PERFIL_CONFIG,
    GESTION_SUCURSALES, GESTION_SERVICIOS, GESTION_EMPLEADOS
}

data class Servicio(val id: Int, val nombre: String, val precio: Double, val duracion: String)
data class Empleado(val id: Int, val nombre: String, val especialidad: String, val sucursal: String)
data class Cita(val id: Int, val clienteNombre: String, val servicio: String, val estilista: String, val fecha: String, val hora: String, val precio: String, val estado: String)

class CitasViewModel : ViewModel() {
    val listaServicios = mutableStateListOf(
        Servicio(1, "Corte Dama", 250.0, "45 min"),
        Servicio(2, "Barbería", 150.0, "30 min")
    )
    val listaEmpleados = mutableStateListOf(
        Empleado(1, "Ana García", "Estilista", "Sucursal Central")
    )
    val listaGlobalCitas = mutableStateListOf<Cita>()
    val SUCURSAL_UNICA = "Estética Estrella - Sede Central"

    fun agregarCita(nuevaCita: Cita) { listaGlobalCitas.add(0, nuevaCita) }

    fun obtenerCitasFiltradas(rol: String, nombre: String): List<Cita> {
        val r = rol.uppercase()
        return if (r == "ADMIN" || r == "EMPLEADO") listaGlobalCitas
        else listaGlobalCitas.filter { it.clienteNombre == nombre }
    }
}

object UserDatabase {
    val usuarios = mutableMapOf(
        "admin@gmail.com" to Triple(hashSHA512("admin123"), "ADMIN", "Administrador"),
        "empleado@gmail.com" to Triple(hashSHA512("empleado123"), "EMPLEADO", "Empleado")
    )
}

class UserDAO {
    fun getUserData(email: String) = UserDatabase.usuarios[email.trim().lowercase()]
    fun addUser(nombre: String, email: String, hash: String, rol: String) {
        UserDatabase.usuarios[email.trim().lowercase()] = Triple(hash, rol.trim().uppercase(), nombre)
    }
}

fun hashSHA512(input: String): String {
    val md = MessageDigest.getInstance("SHA-512")
    val digest = md.digest(input.trim().toByteArray())
    return Base64.encodeToString(digest, Base64.NO_WRAP)
}